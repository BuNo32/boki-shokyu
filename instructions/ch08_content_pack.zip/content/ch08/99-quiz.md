# 第8章 章末クイズ（手形・電子記録債権債務）

<div id="quiz-ch08"
     data-quiz-src="../quizzes/ch08.json"
     data-quiz-id="ch08"
     data-accounts-src="../assets/data/accounts.ch08.json"></div>

[章の目次へ](index.md)
