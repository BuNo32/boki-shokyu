# AGENTS.m08-add.md
目的: 第8章「手形・電子記録債権債務」を“文章主役・.mdリンク”方針で追加し、章末クイズ（18問）を登録する。

前提: サイトは `use_directory_urls: false`。本文リンクは **.md**、ダッシュボード JSON の `page` は **.html**。

完了条件:
- このZIPの `content/` をプロジェクト直下にマージして `mkdocs build --strict` が成功
- 左ナビに「第8章 手形・電子記録債権債務（目次・4節・章末クイズ）」が表示
- ダッシュボードに ch08 クイズが追加

## 0) ブランチ
RUN
```bash
set -euo pipefail
git checkout -b feat/ch08 || git checkout feat/ch08
```

## 1) ファイル配置
- `content/ch08/*.md`
- `content/quizzes/ch08.json`
- `content/assets/data/accounts.ch08.json`
- `content/assets/css/ch08.css`
- `content/assets/img/ch08/*.svg`

## 2) mkdocs.yml を編集（nav と CSS）
EDIT FILE mkdocs.yml
```yaml
nav:
  - 第8章 手形・電子記録債権債務:
      - 章の目次: ch08/index.md
      - 1. 手形のキホン: ch08/01-notes-basics.md
      - 2. 発生→決済（手形）: ch08/02-notes-transactions.md
      - 3. 電子記録債権・債務: ch08/03-densai.md
      - 4. コツ＆Q&A: ch08/04-tips-and-qa.md
      - 章末クイズ: ch08/99-quiz.md

extra_css:
  - assets/css/site.css
  - assets/css/ch08.css
```

## 3) ダッシュボードに ch08 を追加
EDIT FILE content/quizzes/index.json（"quizzes" 配列に追記）
```json
{ "quizId":"ch08", "title":"第8章 手形・電子記録債権債務（章末）",
   "file":"ch08.json", "page":"ch08/99-quiz.html", "basePath":"quizzes/" }
```

## 4) 検証とビルド
RUN
```bash
python scripts/validate_quizzes.py
mkdocs build --strict
mkdocs serve
```

## 5) コミット＆PR
RUN
```bash
git add -A
git commit -m "feat(ch08): add Notes & Densai with text-heavy .md pages, diagrams, and quiz"
git push -u origin feat/ch08
if command -v gh >/dev/null 2>&1; then
  gh pr create -B main -H feat/ch08 -t "ch08: 手形・電子記録債権債務を追加" -b "文章主役・.mdリンク。受取/支払手形と電子記録債権/債務、満期処理、手数料を収録。章末クイズ18問。" 
fi
```
