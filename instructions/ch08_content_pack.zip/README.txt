M08 「手形・電子記録債権債務」コンテンツパック（2025-09-15）
-------------------------------------------------
同梱物:
- 記事: content/ch08/index.md, 01-notes-basics.md, 02-notes-transactions.md, 03-densai.md, 04-tips-and-qa.md, 99-quiz.md
- 付録: glossary.md, cheatsheet.md
- 図: content/assets/img/ch08/notes_flow.svg, endorsement_flow.svg, densai_flow.svg, fourcol_template.svg
- スタイル: content/assets/css/ch08.css
- クイズ: content/quizzes/ch08.json（accounts: content/assets/data/accounts.ch08.json）
- ダッシュボード追記テンプレ: content/quizzes/index.add.ch08.json
- 手順: AGENTS.m08-add.md（Codex CLI 用）

メモ:
- 内部リンクは .md（MkDocs が .html を生成）。ダッシュボード JSON の page は .html。
- 初級の範囲で、発生→決済を中心に扱っています（裏書・割引はイメージまで）。
