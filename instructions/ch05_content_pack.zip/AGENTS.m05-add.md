# AGENTS.m05-add.md
目的: 第5章「現金・預金（応用）」を“文章主役・.mdリンク”方針で追加/置換し、章末クイズ（14問）を登録する。

前提: 現在のクイズ索引には ch01 / ch03 / ch05 / proto が登録済み（ch05 は既存）。必要に応じて置換 or 上書きで対応。

完了条件:
- このZIPの `content/` をプロジェクト直下にマージして `mkdocs build --strict` が成功
- 左ナビに「第5章 現金・預金（応用）（目次・4節・章末クイズ）」が表示
- ダッシュボードの ch05 クイズが稼働

## 0) ブランチ
RUN
```bash
set -euo pipefail
git checkout -b feat/ch05-advanced || git checkout feat/ch05-advanced
```

## 1) ファイル配置
- `content/ch05/*.md`
- `content/quizzes/ch05.json`     # ← 既存があれば置換
- `content/assets/data/accounts.ch05.json`
- `content/assets/css/ch05.css`
- `content/assets/img/ch05/*.svg`

## 2) mkdocs.yml を編集（nav と CSS）
EDIT FILE mkdocs.yml
```yaml
nav:
  - 第5章 現金・預金（応用）:
      - 章の目次: ch05/index.md
      - 1. 銀行手数料と受取利息: ch05/01-fees-and-interest.md
      - 2. 振込と差引入金（2行で解決）: ch05/02-transfers-advanced.md
      - 3. 現金過不足: ch05/03-cash-over-short.md
      - 4. 通帳の見方とメモ: ch05/04-passbook-and-notes.md
      - 章末クイズ: ch05/99-quiz.md

extra_css:
  - assets/css/site.css
  - assets/css/ch05.css
```

## 3) ダッシュボード（必要なら更新）
- 既に `content/quizzes/index.json` に ch05 がある場合は **変更不要**。
- 未登録なら、下記を "quizzes" 配列へ追記。
```json
{ "quizId":"ch05", "title":"第5章 現金・預金（応用）",
   "file":"ch05.json", "page":"ch05/99-quiz.html", "basePath":"quizzes/" }
```

## 4) 検証とビルド
RUN
```bash
python scripts/validate_quizzes.py
mkdocs build --strict
mkdocs serve
```

## 5) コミット＆PR
RUN
```bash
git add -A
git commit -m "feat(ch05): add Advanced Cash & Bank (fees, net receipts, cash over/short, passbook) with text-heavy .md pages and quiz"
git push -u origin feat/ch05-advanced
if command -v gh >/dev/null 2>&1; then
  gh pr create -B main -H feat/ch05-advanced -t "ch05: 現金・預金（応用）を追加" -b "砕けた文章・.mdリンク。手数料/差引入金/現金過不足/通帳の見方を収録。章末クイズ14問。" 
fi
```
