M05 「現金・預金（応用）」コンテンツパック（2025-09-15）
-------------------------------------------------
同梱物:
- 記事: content/ch05/index.md, 01-fees-and-interest.md, 02-transfers-advanced.md, 03-cash-over-short.md, 04-passbook-and-notes.md, 99-quiz.md
- 付録: glossary.md, cheatsheet.md
- 図: content/assets/img/ch05/fee_patterns.svg, net_receipt.svg, cash_over_short.svg, passbook_view.svg
- スタイル: content/assets/css/ch05.css
- クイズ: content/quizzes/ch05.json（accounts: content/assets/data/accounts.ch05.json）
- ダッシュボード追記テンプレ: content/quizzes/index.add.ch05.json
- 手順: AGENTS.m05-add.md（Codex CLI 用）

メモ:
- 本章の内部リンクは .md で記述（MkDocs が .html に変換）
- 既存の ch05 がある場合は上書きで“応用”に差し替え可能（要レビュー）
