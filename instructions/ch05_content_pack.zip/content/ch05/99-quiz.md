# 第5章 章末クイズ（応用）

<div id="quiz-ch05"
     data-quiz-src="../quizzes/ch05.json"
     data-quiz-id="ch05"
     data-accounts-src="../assets/data/accounts.ch05.json"></div>

[章の目次へ](index.md)
