# 第7章 章末クイズ（その他の債権・債務）

<div id="quiz-ch07"
     data-quiz-src="../quizzes/ch07.json"
     data-quiz-id="ch07"
     data-accounts-src="../assets/data/accounts.ch07.json"></div>

[章の目次へ](index.md)
