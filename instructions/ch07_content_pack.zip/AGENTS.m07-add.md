# AGENTS.m07-add.md
目的: 第7章「その他の債権・債務」を“文章主役・.mdリンク”方針で追加し、章末クイズ（16問）を登録する。

前提: サイトは `use_directory_urls: false`。本文リンクは **.md**、ダッシュボード JSON の `page` は **.html**。

完了条件:
- このZIPの `content/` をプロジェクト直下にマージして `mkdocs build --strict` が成功
- 左ナビに「第7章 その他の債権・債務（目次・4節・章末クイズ）」が表示
- ダッシュボードに ch07 クイズが追加

## 0) ブランチ
RUN
```bash
set -euo pipefail
git checkout -b feat/ch07 || git checkout feat/ch07
```

## 1) ファイル配置
- `content/ch07/*.md`
- `content/quizzes/ch07.json`
- `content/assets/data/accounts.ch07.json`
- `content/assets/css/ch07.css`
- `content/assets/img/ch07/*.svg`

## 2) mkdocs.yml を編集（nav と CSS）
EDIT FILE mkdocs.yml
```yaml
nav:
  - 第7章 その他の債権・債務:
      - 章の目次: ch07/index.md
      - 1. まずは地図: ch07/01-overview.md
      - 2. 前金・未収・未払: ch07/02-advance-and-unsettled.md
      - 3. 立替・預り・仮払・仮受: ch07/03-employee-and-temp.md
      - 4. 頻出パターン＆コツ: ch07/04-patterns-and-tips.md
      - 章末クイズ: ch07/99-quiz.md

extra_css:
  - assets/css/site.css
  - assets/css/ch07.css
```

## 3) ダッシュボードに ch07 を追加
EDIT FILE content/quizzes/index.json（"quizzes" 配列に追記）
```json
{ "quizId":"ch07", "title":"第7章 その他の債権・債務（章末）",
   "file":"ch07.json", "page":"ch07/99-quiz.html", "basePath":"quizzes/" }
```

## 4) 検証とビルド
RUN
```bash
python scripts/validate_quizzes.py
mkdocs build --strict
mkdocs serve
```

## 5) コミット＆PR
RUN
```bash
git add -A
git commit -m "feat(ch07): add Other Receivables & Payables with text-heavy .md pages, diagrams, and quiz"
git push -u origin feat/ch07
if command -v gh >/dev/null 2>&1; then
  gh pr create -B main -H feat/ch07 -t "ch07: その他の債権・債務を追加" -b "文章主役・.mdリンク。未収/未払、前払/前受、立替/預り、仮払/仮受を収録。章末クイズ16問。" 
fi
```
