M07 「その他の債権・債務」コンテンツパック（2025-09-15）
-------------------------------------------------
同梱物:
- 記事: content/ch07/index.md, 01-overview.md, 02-advance-and-unsettled.md, 03-employee-and-temp.md, 04-patterns-and-tips.md, 99-quiz.md
- 付録: glossary.md, cheatsheet.md
- 図: content/assets/img/ch07/map_other_ar_ap.svg, timeline_advance_unsettled.svg, temp_accounts.svg
- スタイル: content/assets/css/ch07.css
- クイズ: content/quizzes/ch07.json（accounts: content/assets/data/accounts.ch07.json）
- ダッシュボード追記テンプレ: content/quizzes/index.add.ch07.json
- 手順: AGENTS.m07-add.md（Codex CLI 用）

メモ:
- 本章は「売買以外の債権債務」を扱います（未収入金・未払金／前払金・前受金／立替金・預り金／仮払金・仮受金）。
- 内部リンクは .md（MkDocs が .html を生成）。ダッシュボード JSON の page は .html。
