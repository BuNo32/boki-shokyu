# AGENTS.fix-tables.md
目的: 第5章以降で生じている「表（4列仕訳）が1行に詰まって表示される」不具合を、Markdown整形とCSSで解決する。

完了条件:
- 指定ページの4列仕訳表が「表」として描画される（行ごとに罫線・右寄せが効く）
- MkDocsビルドが `--strict` で成功
- 主要ページでテーブル崩れが再発しない

## 0) ブランチ作成
RUN
```bash
git checkout -b fix/tables-inline-orphan || git checkout fix/tables-inline-orphan
```

## 1) 追加ファイルの配置
COPY
- `content/assets/css/tables-fix.css` → 既存の `content/assets/css/` に配置
- `scripts/check_tables.py` と `scripts/fix_tables.py` → ルートの `scripts/` に配置（なければ作成）

## 2) mkdocs.yml へ CSS を登録
EDIT FILE mkdocs.yml（`extra_css` に追記。重複は無視されます）
```yaml
extra_css:
  - assets/css/site.css
  - assets/css/tables-fix.css
```

## 3) 事前チェック（壊れている可能性の高い行を洗い出し）
RUN
```bash
python scripts/check_tables.py --root .
```

## 4) 自動整形（インライン表→正規のMarkdown表）
RUN
```bash
python scripts/fix_tables.py --root .
```

> 既存ファイルの隣に `.bak` が保存されます。差分を確認してください。

## 5) ビルド確認
RUN
```bash
mkdocs build --strict
mkdocs serve
```

## 6) コミットとPR
RUN
```bash
git add -A
git commit -m "fix(tables): normalize inline 4-column journal tables and add tables-fix.css"
git push -u origin fix/tables-inline-orphan
if command -v gh >/dev/null 2>&1; then
  gh pr create -B main -H fix/tables-inline-orphan -t "fix: 4列仕訳の表崩れを修正" -b "Markdownの表を正規化し、CSSで体裁を統一。ch05〜ch09の対象ページを自動整形。"
fi
```

## （参考）よくある原因と対策
- **原因1: 行頭にキャプション＋表ヘッダが同一行**  
  例）`4列（2行） | 借方科目 | 金額 | ...` → **キャプションを改行**してから表を開始。  
- **原因2: ヘッダ・整列行・データ行が1行に詰め込まれている**  
  → 各行を**改行**して分割（本ツールが対応）。  
- **原因3: 箇条書きの直後に表**  
  → 箇条書きと表の間に**空行**を入れる（本ツールは空行を自動挿入）。

補足: 表の右寄せは CSS（`tables-fix.css`）で2/4列目に適用しています。
