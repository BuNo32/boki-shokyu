Tables Fix Pack (2025-09-16)
========================
目的: 第5章以降のページで、4列仕訳のMarkdown表が「1行テキスト」として表示される不具合を修正します。

同梱物:
- content/assets/css/tables-fix.css … 表の体裁と右寄せを統一
- scripts/check_tables.py … 壊れやすい「インライン表」を検出
- scripts/fix_tables.py … インライン表を正規のMarkdown表へ自動整形（.bak作成）
- AGENTS.fix-tables.md … Codex CLI用の実行手順（そのまま流せます）

使い方（最短）:
1) ZIPをリポジトリ直下に展開（`content/` と `scripts/` をマージ）
2) `mkdocs.yml` の `extra_css` に `assets/css/tables-fix.css` を1行追記
3) `python scripts/fix_tables.py --root .`
4) `mkdocs build --strict` で見た目を確認 → PR

注意:
- 自動整形は以下のファイルを対象にしています（必要に応じて `--targets` で上書き）:
  - content/ch05/01-fees-and-interest.md
  - content/ch05/02-transfers-advanced.md
  - content/ch05/03-cash-over-short.md
  - content/ch06/03-returns-and-allowances.md
  - content/ch07/02-advance-and-unsettled.md
  - content/ch07/03-employee-and-temp.md
  - content/ch08/02-notes-transactions.md
  - content/ch08/03-densai.md
  - content/ch09/02-daily-transactions.md
  - content/ch09/03-returns-and-allowances.md

- `.bak` が自動保存されます。差分確認後に不要であれば削除してください。
