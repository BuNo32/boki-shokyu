# AGENTS.m11-add.md
目的: 第11章「純資産（資本金・元入・引出）」を“文章主役・.mdリンク”方針で追加し、章末クイズ（18問）を登録する。

前提: サイトは `use_directory_urls: false`。本文リンクは **.md**、ダッシュボード JSON の `page` は **.html**。

完了条件:
- このZIPの `content/` をプロジェクト直下にマージして `mkdocs build --strict` が成功
- 左ナビに「第11章 純資産（資本金・元入・引出）（目次・4節・章末クイズ）」が表示
- ダッシュボードに ch11 クイズが追加

## 0) ブランチ
RUN
```bash
set -euo pipefail
git checkout -b feat/ch11 || git checkout feat/ch11
```

## 1) ファイル配置
- `content/ch11/*.md`
- `content/quizzes/ch11.json`
- `content/assets/data/accounts.ch11.json`
- `content/assets/css/ch11.css`
- `content/assets/img/ch11/*.svg`

## 2) mkdocs.yml を編集（nav と CSS）
EDIT FILE mkdocs.yml
```yaml
nav:
  - 第11章 純資産（資本金・元入・引出）:
      - 章の目次: ch11/index.md
      - 1. 純資産のキホン: ch11/01-equity-basics.md
      - 2. 引出金の取り扱い: ch11/02-owner-drawings.md
      - 3. 追加の元入・個人→事業の立替: ch11/03-additional-capital.md
      - 4. 運用のコツ＆Q&A: ch11/04-tips-and-qa.md
      - 章末クイズ: ch11/99-quiz.md

extra_css:
  - assets/css/site.css
  - assets/css/ch11.css
```

## 3) ダッシュボードに ch11 を追加
EDIT FILE content/quizzes/index.json（"quizzes" 配列に追記）
```json
{ "quizId":"ch11", "title":"第11章 純資産（資本金・元入・引出）（章末）",
   "file":"ch11.json", "page":"ch11/99-quiz.html", "basePath":"quizzes/" }
```

## 4) 検証とビルド
RUN
```bash
python scripts/validate_quizzes.py
mkdocs build --strict
mkdocs serve
```

## 5) コミット＆PR
RUN
```bash
git add -A
git commit -m "feat(ch11): add Equity (Capital/Owner’s Equity/Drawings) with text-heavy .md pages, diagrams, and quiz"
git push -u origin feat/ch11
if command -v gh >/dev/null 2>&1; then
  gh pr create -B main -H feat/ch11 -t "ch11: 純資産（資本金・元入・引出）を追加" -b "文章主役・.mdリンク。資本金・元入金・引出金、期末振替、個人→事業の立替を収録。章末クイズ18問。" 
fi
```
