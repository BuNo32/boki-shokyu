M11 「純資産（資本金・元入・引出）」コンテンツパック（2025-09-16）
-------------------------------------------------
同梱物:
- 記事: content/ch11/index.md, 01-equity-basics.md, 02-owner-drawings.md, 03-additional-capital.md, 04-tips-and-qa.md, 99-quiz.md
- 付録: glossary.md, cheatsheet.md
- 図: content/assets/img/ch11/equity_map.svg, drawings_flow.svg, equity_bookvalue.svg
- スタイル: content/assets/css/ch11.css
- クイズ: content/quizzes/ch11.json（accounts: content/assets/data/accounts.ch11.json）
- ダッシュボード追記テンプレ: content/quizzes/index.add.ch11.json
- 手順: AGENTS.m11-add.md（Codex CLI 用）

メモ:
- 内部リンクは .md（MkDocs が .html を生成）。ダッシュボード JSON の page は .html。
- 初級レベルでは「引出金は一時科目／期末に元入金へ振替」を徹底して覚えます。
