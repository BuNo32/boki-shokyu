# 第11章 章末クイズ（純資産：資本金・元入・引出）

<div id="quiz-ch11"
     data-quiz-src="../quizzes/ch11.json"
     data-quiz-id="ch11"
     data-accounts-src="../assets/data/accounts.ch11.json"></div>

[章の目次へ](index.md)
