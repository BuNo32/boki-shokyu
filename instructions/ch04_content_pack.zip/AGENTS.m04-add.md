# AGENTS.m04-add.md
目的: 第4章「現金・預金（基礎）」を“砕けた口調・文章主役・.mdリンク”方針で追加し、章末クイズを登録する。

完了条件:
- このZIPの `content/` をプロジェクト直下にマージして `mkdocs build --strict` が成功
- 左ナビに「第4章 現金・預金（基礎）（目次・4節・章末クイズ）」が追加
- ダッシュボードに ch04 クイズが表示

## 0) ブランチ
RUN
```bash
set -euo pipefail
git checkout -b feat/ch04 || git checkout feat/ch04
```

## 1) ファイル配置
- `content/ch04/*.md`
- `content/quizzes/ch04.json`
- `content/assets/data/accounts.ch04.json`
- `content/assets/css/ch04.css`
- `content/assets/img/ch04/*.svg`

## 2) mkdocs.yml を編集（nav と CSS）
EDIT FILE mkdocs.yml
```yaml
nav:
  - 第4章 現金・預金（基礎）:
      - 章の目次: ch04/index.md
      - 1. 現金・預金の素振り: ch04/01-basics.md
      - 2. 手段→勘定のルール: ch04/02-methods-to-accounts.md
      - 3. 10のパターン: ch04/03-ten-patterns.md
      - 4. ミス対策チェック: ch04/04-errors-and-checklist.md
      - 章末クイズ: ch04/99-quiz.md

extra_css:
  - assets/css/site.css
  - assets/css/ch04.css
```

## 3) ダッシュボードに ch04 を追加（追記）
EDIT FILE content/quizzes/index.json（配列に下記を追記）
```json
{ "quizId":"ch04", "title":"第4章 現金・預金（基礎）",
   "file":"ch04.json", "page":"ch04/99-quiz.html", "basePath":"quizzes/" }
```

## 4) 検証とビルド
RUN
```bash
python scripts/validate_quizzes.py
mkdocs build --strict
mkdocs serve
```

## 5) コミット＆PR
RUN
```bash
git add -A
git commit -m "feat(ch04): add Chapter 4 (現金・預金・基礎) with friendly text-heavy pages, diagrams, and quiz"
git push -u origin feat/ch04
if command -v gh >/dev/null 2>&1; then
  gh pr create -B main -H feat/ch04 -t "ch04: 現金・預金（基礎）を追加" -b "砕けた文章・.mdリンク・4列仕訳の練習を重視。章末クイズは12問。" 
fi
```
