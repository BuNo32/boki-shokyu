M04 「現金・預金（基礎）」コンテンツパック（2025-09-15）
-------------------------------------------------
同梱物:
- 記事: content/ch04/index.md, 01-basics.md, 02-methods-to-accounts.md, 03-ten-patterns.md, 04-errors-and-checklist.md, 99-quiz.md
- 付録: glossary.md, cheatsheet.md
- 図: content/assets/img/ch04/method_to_account.svg, cash_bank_flow.svg, fourcol_template.svg
- スタイル: content/assets/css/ch04.css
- クイズ: content/quizzes/ch04.json（accounts: content/assets/data/accounts.ch04.json）
- ダッシュボード追記テンプレ: content/quizzes/index.add.ch04.json
- 手順: AGENTS.m04-add.md（Codex CLI 用）

メモ:
- 本章の内部リンクは .md で記述（MkDocs が .html に変換）
- 既存の ch05（現金・預金 総合）があっても並存可：ch04=基礎、ch05=総合/発展の位置づけ
