# 第4章 章末クイズ（現金・預金 基礎）

<div id="quiz-ch04"
     data-quiz-src="../quizzes/ch04.json"
     data-quiz-id="ch04"
     data-accounts-src="../assets/data/accounts.ch04.json"></div>

[章の目次へ](index.md)
