# AGENTS.m09-add.md
目的: 第9章「商品売買（三分法）・返品」を“文章主役・.mdリンク”方針で追加し、章末クイズ（18問）を登録する。

前提: サイトは `use_directory_urls: false`。本文リンクは **.md**、ダッシュボード JSON の `page` は **.html**。

完了条件:
- このZIPの `content/` をプロジェクト直下にマージして `mkdocs build --strict` が成功
- 左ナビに「第9章 商品売買（三分法）・返品（目次・4節・章末クイズ）」が表示
- ダッシュボードに ch09 クイズが追加

## 0) ブランチ
RUN
```bash
set -euo pipefail
git checkout -b feat/ch09 || git checkout feat/ch09
```

## 1) ファイル配置
- `content/ch09/*.md`
- `content/quizzes/ch09.json`
- `content/assets/data/accounts.ch09.json`
- `content/assets/css/ch09.css`
- `content/assets/img/ch09/*.svg`

## 2) mkdocs.yml を編集（nav と CSS）
EDIT FILE mkdocs.yml
```yaml
nav:
  - 第9章 商品売買（三分法）・返品:
      - 章の目次: ch09/index.md
      - 1. 三分法のキホン: ch09/01-three-way-basics.md
      - 2. 日常処理（現金・掛け・運賃）: ch09/02-daily-transactions.md
      - 3. 返品・値引: ch09/03-returns-and-allowances.md
      - 4. 期末のイメージ: ch09/04-period-end-idea-and-tips.md
      - 章末クイズ: ch09/99-quiz.md

extra_css:
  - assets/css/site.css
  - assets/css/ch09.css
```

## 3) ダッシュボードに ch09 を追加
EDIT FILE content/quizzes/index.json（"quizzes" 配列に追記）
```json
{ "quizId":"ch09", "title":"第9章 商品売買（三分法）・返品（章末）",
   "file":"ch09.json", "page":"ch09/99-quiz.html", "basePath":"quizzes/" }
```

## 4) 検証とビルド
RUN
```bash
python scripts/validate_quizzes.py
mkdocs build --strict
mkdocs serve
```

## 5) コミット＆PR
RUN
```bash
git add -A
git commit -m "feat(ch09): add Periodic (三分法) & Returns with text-heavy .md pages, diagrams, and quiz"
git push -u origin feat/ch09
if command -v gh >/dev/null 2>&1; then
  gh pr create -B main -H feat/ch09 -t "ch09: 商品売買（三分法）・返品を追加" -b "文章主役・.mdリンク。現金/掛け/運賃、売上返品・仕入返品、期末イメージ。章末クイズ18問。" 
fi
```
