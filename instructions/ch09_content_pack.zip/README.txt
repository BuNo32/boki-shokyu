M09 「商品売買（三分法）・返品」コンテンツパック（2025-09-16）
-------------------------------------------------
同梱物:
- 記事: content/ch09/index.md, 01-three-way-basics.md, 02-daily-transactions.md, 03-returns-and-allowances.md, 04-period-end-idea-and-tips.md, 99-quiz.md
- 付録: glossary.md, cheatsheet.md
- 図: content/assets/img/ch09/three_way_map.svg, periodic_flow.svg, returns_patterns.svg, freight_rules.svg, fourcol_template.svg
- スタイル: content/assets/css/ch09.css
- クイズ: content/quizzes/ch09.json（accounts: content/assets/data/accounts.ch09.json）
- ダッシュボード追記テンプレ: content/quizzes/index.add.ch09.json
- 手順: AGENTS.m09-add.md（Codex CLI 用）

メモ:
- 内部リンクは .md（MkDocs が .html を生成）。ダッシュボード JSON の page は .html。
- 期末の詳細仕訳（期首・期末の繰越商品）はイメージ説明に留め、実際の決算整理は後章で扱います。
