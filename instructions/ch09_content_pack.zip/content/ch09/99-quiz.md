# 第9章 章末クイズ（商品売買・三分法・返品）

<div id="quiz-ch09"
     data-quiz-src="../quizzes/ch09.json"
     data-quiz-id="ch09"
     data-accounts-src="../assets/data/accounts.ch09.json"></div>

[章の目次へ](index.md)
