# AGENTS.m10-add.md
目的: 第10章「固定資産（取得・減価償却）」を“文章主役・.mdリンク”方針で追加し、章末クイズ（18問）を登録する。

前提: サイトは `use_directory_urls: false`。本文リンクは **.md**、ダッシュボード JSON の `page` は **.html**。

完了条件:
- このZIPの `content/` をプロジェクト直下にマージして `mkdocs build --strict` が成功
- 左ナビに「第10章 固定資産（取得・減価償却）（目次・4節・章末クイズ）」が表示
- ダッシュボードに ch10 クイズが追加

## 0) ブランチ
RUN
```bash
set -euo pipefail
git checkout -b feat/ch10 || git checkout feat/ch10
```

## 1) ファイル配置
- `content/ch10/*.md`
- `content/quizzes/ch10.json`
- `content/assets/data/accounts.ch10.json`
- `content/assets/css/ch10.css`
- `content/assets/img/ch10/*.svg`

## 2) mkdocs.yml を編集（nav と CSS）
EDIT FILE mkdocs.yml
```yaml
nav:
  - 第10章 固定資産（取得・減価償却）:
      - 章の目次: ch10/index.md
      - 1. 取得のキホン: ch10/01-acquisition-basics.md
      - 2. 減価償却のキホン: ch10/02-depreciation-basics.md
      - 3. 例題で定着: ch10/03-depreciation-examples.md
      - 4. 修繕と改良: ch10/04-maintenance-vs-capex.md
      - 章末クイズ: ch10/99-quiz.md

extra_css:
  - assets/css/site.css
  - assets/css/ch10.css
```

## 3) ダッシュボードに ch10 を追加
EDIT FILE content/quizzes/index.json（"quizzes" 配列に追記）
```json
{ "quizId":"ch10", "title":"第10章 固定資産（取得・減価償却）（章末）",
   "file":"ch10.json", "page":"ch10/99-quiz.html", "basePath":"quizzes/" }
```

## 4) 検証とビルド
RUN
```bash
python scripts/validate_quizzes.py
mkdocs build --strict
mkdocs serve
```

## 5) コミット＆PR
RUN
```bash
git add -A
git commit -m "feat(ch10): add Fixed Assets (Acquisition & Straight-line Depreciation) with text-heavy .md pages, diagrams, and quiz"
git push -u origin feat/ch10
if command -v gh >/dev/null 2>&1; then
  gh pr create -B main -H feat/ch10 -t "ch10: 固定資産（取得・減価償却）を追加" -b "文章主役・.mdリンク。取得原価・定額法・帳簿価額、修繕と改良。章末クイズ18問。" 
fi
```
