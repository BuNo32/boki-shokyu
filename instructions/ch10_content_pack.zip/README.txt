M10 「固定資産（取得・減価償却）」コンテンツパック（2025-09-16）
-------------------------------------------------
同梱物:
- 記事: content/ch10/index.md, 01-acquisition-basics.md, 02-depreciation-basics.md, 03-depreciation-examples.md, 04-maintenance-vs-capex.md, 99-quiz.md
- 付録: glossary.md, cheatsheet.md
- 図: content/assets/img/ch10/acquisition_cost.svg, straight_line.svg, depr_timeline.svg, book_value.svg
- スタイル: content/assets/css/ch10.css
- クイズ: content/quizzes/ch10.json（accounts: content/assets/data/accounts.ch10.json）
- ダッシュボード追記テンプレ: content/quizzes/index.add.ch10.json
- 手順: AGENTS.m10-add.md（Codex CLI 用）

メモ:
- 内部リンクは .md（MkDocs が .html を生成）。ダッシュボード JSON の page は .html。
- 初級では定額法中心で説明。税法の細則や特例には踏み込みません。
