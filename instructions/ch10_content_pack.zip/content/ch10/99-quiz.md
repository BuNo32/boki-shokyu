# 第10章 章末クイズ（固定資産：取得・減価償却）

<div id="quiz-ch10"
     data-quiz-src="../quizzes/ch10.json"
     data-quiz-id="ch10"
     data-accounts-src="../assets/data/accounts.ch10.json"></div>

[章の目次へ](index.md)
