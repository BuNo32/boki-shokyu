M06 「売掛金・買掛金・クレジット売掛金」コンテンツパック（2025-09-15）
-------------------------------------------------
同梱物:
- 記事: content/ch06/index.md, 01-ar-ap-basics.md, 02-credit-sales.md, 03-returns-and-allowances.md, 04-reconcile-and-tips.md, 99-quiz.md
- 付録: glossary.md, cheatsheet.md
- 図: content/assets/img/ch06/ar_ap_flow.svg, credit_flow.svg, cc_net_settlement.svg, reconcile_tb.svg
- スタイル: content/assets/css/ch06.css
- クイズ: content/quizzes/ch06.json（accounts: content/assets/data/accounts.ch06.json）
- ダッシュボード追記テンプレ: content/quizzes/index.add.ch06.json
- 手順: AGENTS.m06-add.md（Codex CLI 用）

メモ:
- 本章の内部リンクは .md（MkDocs が .html を生成）
- サイト設定 `use_directory_urls: false` を前提に、ダッシュボード JSON の `page` は .html を指す
