# AGENTS.m06-add.md
目的: 第6章「売掛金・買掛金・クレジット売掛金」を“文章主役・.mdリンク”方針で追加し、章末クイズ（16問）を登録する。

前提: サイトは `use_directory_urls: false`。本文の内部リンクは **.md**、ダッシュボード JSON の `page` は **.html** を指す。

完了条件:
- このZIPの `content/` をプロジェクト直下にマージして `mkdocs build --strict` が成功
- 左ナビに「第6章 売掛金・買掛金・クレジット売掛金（目次・4節・章末クイズ）」が表示
- ダッシュボードに ch06 クイズが追加

## 0) ブランチ
RUN
```bash
set -euo pipefail
git checkout -b feat/ch06 || git checkout feat/ch06
```

## 1) ファイル配置
- `content/ch06/*.md`
- `content/quizzes/ch06.json`
- `content/assets/data/accounts.ch06.json`
- `content/assets/css/ch06.css`
- `content/assets/img/ch06/*.svg`

## 2) mkdocs.yml を編集（nav と CSS）
EDIT FILE mkdocs.yml
```yaml
nav:
  - 第6章 売掛金・買掛金・クレジット売掛金:
      - 章の目次: ch06/index.md
      - 1. 売掛・買掛の基本: ch06/01-ar-ap-basics.md
      - 2. クレジット売掛金: ch06/02-credit-sales.md
      - 3. 返品・値引: ch06/03-returns-and-allowances.md
      - 4. 締めと突合: ch06/04-reconcile-and-tips.md
      - 章末クイズ: ch06/99-quiz.md

extra_css:
  - assets/css/site.css
  - assets/css/ch06.css
```

## 3) ダッシュボードに ch06 を追加
EDIT FILE content/quizzes/index.json（"quizzes" 配列に追記）
```json
{ "quizId":"ch06", "title":"第6章 売掛金・買掛金・クレジット売掛金（章末）",
   "file":"ch06.json", "page":"ch06/99-quiz.html", "basePath":"quizzes/" }
```

## 4) 検証とビルド
RUN
```bash
python scripts/validate_quizzes.py
mkdocs build --strict
mkdocs serve
```

## 5) コミット＆PR
RUN
```bash
git add -A
git commit -m "feat(ch06): add Accounts Receivable/Payable & Credit Sales with text-heavy .md pages, diagrams, and quiz"
git push -u origin feat/ch06
if command -v gh >/dev/null 2>&1; then
  gh pr create -B main -H feat/ch06 -t "ch06: 売掛金・買掛金・クレジット売掛金を追加" -b "文章主役・.mdリンク。カード売上の差引入金は2行方式で。章末クイズ16問。" 
fi
```
