# 第6章 章末クイズ（売掛金・買掛金・クレジット売掛金）

<div id="quiz-ch06"
     data-quiz-src="../quizzes/ch06.json"
     data-quiz-id="ch06"
     data-accounts-src="../assets/data/accounts.ch06.json"></div>

[章の目次へ](index.md)
