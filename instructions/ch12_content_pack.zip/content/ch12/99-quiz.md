# 第12章 章末クイズ（収益・費用と税金：税抜）

<div id="quiz-ch12"
     data-quiz-src="../quizzes/ch12.json"
     data-quiz-id="ch12"
     data-accounts-src="../assets/data/accounts.ch12.json"></div>

[章の目次へ](index.md)
