M12 「収益・費用と税金（税抜）」コンテンツパック（2025-09-16）
-------------------------------------------------
同梱物:
- 記事: content/ch12/index.md, 01-rev-exp-basics.md, 02-tax-excluded-basics.md, 03-patterns-and-examples.md, 04-period-end-settlement.md, 99-quiz.md
- 付録: glossary.md, cheatsheet.md
- 図: content/assets/img/ch12/vat_flow.svg, tax_excluded_journal.svg, fourcol_template.svg
- スタイル: content/assets/css/ch12.css
- クイズ: content/quizzes/ch12.json（accounts: content/assets/data/accounts.ch12.json）
- ダッシュボード追記テンプレ: content/quizzes/index.add.ch12.json
- 手順: AGENTS.m12-add.md（Codex CLI 用）

注意:
- **テーブル直前に必ず空行**を入れています（表のレンダリング崩れ対策）。
- 内部リンクは .md（MkDocs が .html を生成）。ダッシュボード JSON の page は .html。
