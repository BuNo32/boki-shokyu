# AGENTS.m12-add.md
目的: 第12章「収益・費用と税金（税抜）」を“文章主役・.mdリンク”方針で追加し、章末クイズ（18問）を登録する。

前提: サイトは `use_directory_urls: false`。本文リンクは **.md**、ダッシュボード JSON の `page` は **.html**。

完了条件:
- このZIPの `content/` をプロジェクト直下にマージして `mkdocs build --strict` が成功
- 左ナビに「第12章 収益・費用と税金（税抜）（目次・4節・章末クイズ）」が表示
- ダッシュボードに ch12 クイズが追加
- **すべての .md で、各テーブルの直前に空行がある**（表レンダリング崩れ防止）

## 0) ブランチ
RUN
```bash
set -euo pipefail
git checkout -b feat/ch12 || git checkout feat/ch12
```

## 1) ファイル配置
- `content/ch12/*.md`
- `content/quizzes/ch12.json`
- `content/assets/data/accounts.ch12.json`
- `content/assets/css/ch12.css`
- `content/assets/img/ch12/*.svg`

## 2) mkdocs.yml を編集（nav と CSS）
EDIT FILE mkdocs.yml
```yaml
nav:
  - 第12章 収益・費用と税金（税抜）:
      - 章の目次: ch12/index.md
      - 1. 収益・費用のキホン: ch12/01-rev-exp-basics.md
      - 2. 税抜方式のキホン: ch12/02-tax-excluded-basics.md
      - 3. よくある取引パターン: ch12/03-patterns-and-examples.md
      - 4. 期末の精算: ch12/04-period-end-settlement.md
      - 章末クイズ: ch12/99-quiz.md

extra_css:
  - assets/css/site.css
  - assets/css/ch12.css
```

## 3) ダッシュボードに ch12 を追加
EDIT FILE content/quizzes/index.json（"quizzes" 配列に追記）
```json
{ "quizId":"ch12", "title":"第12章 収益・費用と税金（税抜）（章末）",
   "file":"ch12.json", "page":"ch12/99-quiz.html", "basePath":"quizzes/" }
```

## 4) 体裁チェック（空行ルール）
RUN
```bash
# テーブル直前の空行を機械的に点検（macOS/Linux）
grep -nH "^[|]" content/ch12/*.md | cut -d: -f1 | sort -u | while read f; do
  echo "Check: $f"
done
# 必要なら手で1行空ける。すべての見本は空行済み。
```

## 5) 検証とビルド
RUN
```bash
python scripts/validate_quizzes.py || true
mkdocs build --strict
mkdocs serve
```

## 6) コミット＆PR
RUN
```bash
git add -A
git commit -m "feat(ch12): add Revenue/Expense & VAT (tax-excluded) with text-heavy .md pages, diagrams, and quiz"
git push -u origin feat/ch12
if command -v gh >/dev/null 2>&1; then
  gh pr create -B main -H feat/ch12 -t "ch12: 収益・費用と税金（税抜）を追加" -b "文章主役・.mdリンク。仮受/仮払、期末精算、代表取引の4列仕訳。章末クイズ18問。テーブル直前の空行ルール対応。" 
fi
```
